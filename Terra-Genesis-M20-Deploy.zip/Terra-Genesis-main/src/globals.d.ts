/** Build identity (commit · build time), injected by vite.config.ts. */
declare const __APP_VERSION__: string;
