import { refreshExposed, type WorldState } from '../../engine/world';
import type { ClimateField } from '../climate/climate';
import { YEAR_S } from '../climate/climate';

/**
 * Glaciers (spec E8), CPU, run on a slow cadence (every intervalS of simulated water time) in
 * accelerated glacier time: each update advances dtWater × yearsPerSimHour · YEAR_S / 3600 seconds.
 *
 * Mass balance (m of ice per year, applied each substep), linear in height about the equilibrium line (ELA):
 *   b = β · (z − z_ELA), capped at bMax above; accumulation (b > 0) scaled by the climate rain factor.
 *   z_ELA is where the annual-mean temperature equals elaTempC: z_ELA = sea + (T₀ − elaTempC)/Γ.
 *   Ablation only removes ice that exists. Ice reaching the sea calves (removed, ledgered).
 * Flow: shallow-ice approximation on cell faces, surface s = ground + ice:
 *   q = −(1 + f_s) · Γ_i · H⁵ · |∇s|² · ∇s,  Γ_i = 2A(ρg)³/5  (Glen n = 3; f_s = sliding / deformation)
 *   H on a face = the upstream (higher-surface) cell's ice, so ice-free cells cannot lose ice;
 *   |∇s| from the face-normal and averaged transverse slopes. Each substep (≤ 5 years, and
 *   short enough that dt·D_max/cs² ≤ 100) is semi-implicit: face diffusivities D are frozen and (I − dt∇·D∇)H' = H + dt∇·(D∇z) is solved by
 *   Jacobi-preconditioned conjugate gradients; the fluxes of that solution then move the ice as
 *   pairwise donor-limited transfers — stable at long steps, exactly conservative, never negative.
 *   |∇s|² in D is capped at 0.16 (slope 0.4: steeper icefalls are outside the SIA). Mass balance
 *   is applied per substep, so glacier time = flow time.
 *   At most MAX_SUBSTEPS per update and `budgetMs` of wall-clock time: beyond that the glacier
 *   clock lags and the lag is reported; transfers capped by the ice a donor holds.
 *   Map edges: ice leaves where the ground slopes outward (ghost cell continues the slope), booked
 *   as exported with its debris; no ice flows in.
 * Erosion (abrasion): bed lowering = abrasionK · u_b · dt, u_b = f_s/(1+f_s) · |q|/H (sliding speed,
 *   under ice ≥ 10 m thick, capped at 2 km/yr; optionally at most maxErosionMmYr — 10 in geological time);
 *   loose sediment first, then bedrock (exact float32 deltas). Eroded rock is carried in the ice as
 *   debris (moved with the ice fraction transferred) and dropped as loose sediment where ice thins
 *   below DROP_ICE_M — moraines at the snout. Ice and debris ledgers close.
 * Meltwater: ablated ice (as water, ×0.917) reaches the rivers at the real-time rate — the ablated
 *   volume ÷ the time acceleration — and is booked as a water-ledger input (glacierMeltIn), the same
 *   separation of geomorphic and water time as erosion's speedup.
 * Limits: no thermodynamics, no longitudinal stresses (icefalls are approximate), no subglacial
 * hydrology; ice sits on the terrain surface; fine landforms (corries, arêtes) are below grid scale.
 */
export interface GlacierParams {
  enabled: boolean;
  /** Glacier time per simulated hour (years). */
  yearsPerSimHour: number;
  /** Mass-balance gradient (m ice per year per m of height). */
  balanceGradient: number;
  /** Maximum accumulation (m ice per year). */
  maxAccumulation: number;
  /** Annual-mean temperature at the equilibrium line (°C). */
  elaTempC: number;
  /** Basal sliding as a multiple of internal deformation. */
  slidingFactor: number;
  /** Abrasion: m of bed eroded per m of sliding. */
  abrasionK: number;
  /** Cadence (simulated water seconds). */
  intervalS: number;
  /**
   * Shade and drifting snow (m of ice per year): added on slopes facing north-east, taken away on
   * slopes facing south-west, scaled by steepness (full at 17°). In the UK the prevailing wind is
   * south-westerly and north-east-facing slopes get least sun, so snow lasts there and most corries
   * face between north and east. 0 = off.
   */
  aspectBalance?: number;
  /**
   * Erosion law: 'linear' (abrasionK × sliding distance, Hallet 1979) or 'herman' (2.7e-7 × u_b² m/yr
   * with u_b in m/yr — fitted to measured erosion and sliding of New Zealand glaciers, Herman et al. 2015,
   * Science 350; it concentrates erosion where ice slides fastest, which is what over-deepens troughs).
   */
  erosionLaw?: 'linear' | 'herman';
  /**
   * Longitudinal coupling (cells): the shallow-ice approximation lets every cell slide at its own speed,
   * so thick mid-valley ice races while its margins barely move and erosion cuts a V. Real glaciers move
   * more like a plug — stress gradients couple the motion over 1–4 ice thicknesses (Kamb & Echelmeyer
   * 1986) — so the whole bed is scoured and valleys become U-shaped. When > 0, the sliding speed is
   * averaged over ice-covered cells within this radius before it erodes (box filter, applied twice).
   */
  slidingCoupling?: number;
  /** Fastest erosion allowed (mm/yr); unset = no cap. Geological time uses 10, the top of the range measured for temperate valley glaciers. */
  maxErosionMmYr?: number;
}

export function defaultGlacierParams(): GlacierParams {
  return { enabled: false, yearsPerSimHour: 10, balanceGradient: 0.007, maxAccumulation: 2, elaTempC: -6, slidingFactor: 1, abrasionK: 1e-4, intervalS: 600 };
}

export interface GlacierLedger {
  /** Ice gained by accumulation (m³ of ice). */
  accumulated: number;
  /** Ice lost to melt (m³ of ice). */
  ablated: number;
  /** Ice lost by calving into the sea (m³). */
  calved: number;
  /** Ice added by clamping tiny negative thicknesses from the implicit solve (m³, numerical). */
  correction: number;
  /** Ice (and the debris it carries) that flowed off the map edges (m³). */
  exported: number;
  debrisExported: number;
  /** Rock eroded by the ice (m³) — of which bedrock. */
  eroded: number;
  erodedBedrock: number;
  /** Debris dropped from the ice as moraine / on the sea floor (m³). */
  deposited: number;
  /** Glacier time advanced (s) and time the CFL cap could not run (s). */
  timeS: number;
  lagS: number;
  /** Ice and debris volume at the last reset (m³). */
  initialIce: number;
  initialDebris: number;
}

const RHO_I = 917;
const G = 9.81;
const GLEN_A = 2.4e-24;
const GAMMA = (2 * GLEN_A * Math.pow(RHO_I * G, 3)) / 5;
const MAX_SUBSTEPS = 2000;
/** Longest substep (s): mass balance is applied per substep. */
const MAX_SUB_S = 5 * YEAR_S;
/** Largest dt·D/cs² per substep: implicit, but bounded so CG converges in a few hundred iterations. */
const MAX_IMPLICIT_RATIO = 100;
/** Sliding (and so abrasion) only under ice this thick, capped at 2 km/yr (valley glaciers, not surges). */
const MIN_SLIDE_ICE_M = 10;
const MAX_SLIDE_MS = 2000 / YEAR_S;
/** Surface slope used in the flow law is capped (the SIA does not hold on icefalls). */
const MAX_SLOPE2 = 0.16;
const DROP_ICE_M = 0.5;
export const ICE_TO_WATER = RHO_I / 1000;
/** Herman et al. (2015) erosion coefficient (m⁻¹ yr): erosion (m/yr) = HERMAN_KG × u_b(m/yr)². */
const HERMAN_KG = 2.7e-7;

export class GlacierSim {
  ledger: GlacierLedger;
  private sinceLast = 0;
  /** Implicit solves that hit the CG iteration cap (diagnostic; should stay 0). */
  unconverged = 0;
  private lastSolveConverged = true;
  /** Wall-clock budget per update (ms); glacier time that does not fit is reported as lag. */
  budgetMs = Infinity;
  /**
   * Erosion time per unit of ice time (geological time: the ice is run for a short spell to reach its
   * near-steady state for the current bed, and its abrasion applied for the whole geological step).
   */
  erosionFactor = 1;
  /**
   * Meltwater outwash: this share of the debris released where ice melts is carried away by meltwater
   * rivers (added to `outwash`, m over the cell, for the river model to route) instead of being left
   * as moraine. 0 = all left as moraine (water time). Temperate glaciers export most of their load in
   * meltwater (e.g. Hallet et al. 1996), so geological time (long glacials, margins reworked by meltwater) uses 0.95.
   */
  meltwaterShare = 0;
  outwash: Float64Array | null = null;
  /** If set, debris the ice leaves behind as moraine is also added here (m), so moraine can be told from other sediment. */
  moraine: Float32Array | null = null;
  /** If set, rock and sediment eroded by the ice is added here (m per cell). */
  erosionRecord: Float32Array | null = null;
  /** Fastest sliding speed at the last update (m/yr) — for display. */
  maxSlideMPerYr = 0;
  private qx: Float64Array;
  private qy: Float64Array;
  private h0Buf: Float64Array;
  private rhsBuf: Float64Array;
  private diagBuf: Float64Array;
  private fqBuf: Float64Array;
  private outBuf: Float64Array;
  private qcBuf: Float64Array;
  private limBuf: Float64Array;
  private dIceBuf: Float64Array;
  private dDebBuf: Float64Array;
  private ubBuf: Float64Array;
  private coupleTmpBuf: Float64Array;
  private cgXBuf: Float64Array;
  private cgRBuf: Float64Array;
  private cgZvBuf: Float64Array;
  private cgPvBuf: Float64Array;
  private cgApBuf: Float64Array;

  constructor(
    private world: WorldState,
    private surface: Float32Array,
    private climate: ClimateField,
  ) {
    const n = world.width * world.height;
    this.qx = new Float64Array(n);
    this.qy = new Float64Array(n);
    this.h0Buf = new Float64Array(n);
    this.rhsBuf = new Float64Array(n);
    this.diagBuf = new Float64Array(n);
    this.fqBuf = new Float64Array(2 * n);
    this.outBuf = new Float64Array(n);
    this.qcBuf = new Float64Array(n);
    this.limBuf = new Float64Array(n);
    this.dIceBuf = new Float64Array(n);
    this.dDebBuf = new Float64Array(n);
    this.ubBuf = new Float64Array(n);
    this.coupleTmpBuf = new Float64Array(n);
    this.cgXBuf = new Float64Array(n);
    this.cgRBuf = new Float64Array(n);
    this.cgZvBuf = new Float64Array(n);
    this.cgPvBuf = new Float64Array(n);
    this.cgApBuf = new Float64Array(n);
    this.ledger = this.emptyLedger();
  }

  private emptyLedger(): GlacierLedger {
    return { accumulated: 0, ablated: 0, calved: 0, correction: 0, exported: 0, debrisExported: 0, eroded: 0, erodedBedrock: 0, deposited: 0, timeS: 0, lagS: 0, initialIce: this.iceVolume(), initialDebris: this.debrisVolume() };
  }

  resetLedger() {
    this.ledger = this.emptyLedger();
  }

  get params(): GlacierParams {
    return this.world.glacier;
  }

  iceVolume(): number {
    let v = 0;
    for (const h of this.world.iceThicknessM) v += h;
    return v * this.world.cellSizeM * this.world.cellSizeM;
  }

  debrisVolume(): number {
    let v = 0;
    for (const d of this.world.iceDebrisM) v += d;
    return v * this.world.cellSizeM * this.world.cellSizeM;
  }

  accumulate(dtWater: number): boolean {
    if (!this.params.enabled || !this.world.climate.enabled) return false;
    this.sinceLast += dtWater;
    return this.sinceLast >= this.params.intervalS;
  }

  /** Run the accumulated interval. Returns meltwater per cell (m of water depth, real-time share). */
  update(): Float32Array | null {
    const dt = this.sinceLast;
    this.sinceLast = 0;
    if (!this.params.enabled || dt <= 0) return null;
    return this.run((dt * this.params.yearsPerSimHour * YEAR_S) / 3600, dt);
  }

  /**
   * Advance glacier time dtGeo (s). dtWater is the matching water time, used to scale meltwater
   * to the real-time rate. Returns per-cell meltwater depth (m) to add to surface water.
   */
  run(dtGeo: number, dtWater: number): Float32Array {
    const w = this.world;
    const W = w.width;
    const H = w.height;
    const n = W * H;
    const cs = w.cellSizeM;
    const A = cs * cs;
    const p = this.params;
    const c = w.climate;
    const ice = w.iceThicknessM;
    const deb = w.iceDebrisM;
    const z = this.surface;
    const melt = new Float32Array(n);
    const lapse = c.lapseRateCPerKm / 1000;
    const zEla = w.seaLevelM + (c.seaLevelTempC - p.elaTempC) / Math.max(1e-6, lapse);
    const scale = dtWater / Math.max(dtGeo, 1e-9); // meltwater real-time share
    const aspect = p.aspectBalance ? this.aspectTerm(p.aspectBalance) : null;

    let acc = 0;
    let abl = 0;
    let calv = 0;
    let dropped = 0;
    // Mass balance and calving for a substep of `sub` seconds (interleaved with flow, so ice only
    // accumulates for glacier time that the flow actually simulates).
    const balance = (sub: number) => {
      const years = sub / YEAR_S;
      for (let i = 0; i < n; i++) {
        if (z[i] < w.seaLevelM) {
          if (ice[i] > 0) {
            calv += ice[i];
            ice[i] = 0;
          }
          if (deb[i] > 0) this.drop(i, deb[i]), (dropped += deb[i]), (deb[i] = 0);
          continue;
        }
        const zs = z[i] + ice[i];
        let bm = p.balanceGradient * (zs - zEla);
        if (bm > 0) bm = Math.min(p.maxAccumulation, bm) * this.climate.rainFactor[i];
        if (aspect) bm += aspect[i];
        const dh = bm * years;
        if (dh >= 0) {
          ice[i] += dh;
          acc += dh;
        } else if (ice[i] > 0) {
          const m = Math.min(ice[i], -dh);
          ice[i] -= m;
          abl += m;
          melt[i] += m * ICE_TO_WATER * scale;
        }
      }
    };
    // 2. Flow + erosion: semi-implicit substeps (backward Euler with face diffusivities frozen at
    //    the start of the substep, solved by Jacobi-preconditioned conjugate gradients).
    let t = 0;
    let steps = 0;
    let eroded = 0;
    let erodedB = 0;
    let exported = 0;
    let debExported = 0;
    let correction = 0;
    this.maxSlideMPerYr = 0;
    const fs = p.slidingFactor;
    const slideShare = fs / (1 + fs);
    const Dx = this.qx; // reused as face diffusivities, then fluxes
    const Dy = this.qy;
    const wall0 = performance.now();
    const k2 = 1 / (cs * cs);
    while (t < dtGeo - 1e-6 && steps < MAX_SUBSTEPS && performance.now() - wall0 < this.budgetMs) {
      // Face diffusivities from the upstream cell's ice (no ice ⇒ no outflow from that cell).
      let anyIce = false;
      let dMax = 0;
      for (let i = 0; i < n; i++) {
        const x = i % W;
        Dx[i] = 0;
        Dy[i] = 0;
        if (ice[i] > 0) anyIce = true;
        if (x < W - 1) Dx[i] = this.faceD(i, i + 1, x, Math.floor(i / W), true, fs);
        if (i + W < n) Dy[i] = this.faceD(i, i + W, x, Math.floor(i / W), false, fs);
        dMax = Math.max(dMax, Dx[i], Dy[i]);
      }
      // Substep: ≤ MAX_SUB_S and dt·D_max/cs² ≤ MAX_IMPLICIT_RATIO (keeps CG well conditioned).
      const sub = Math.min(dtGeo - t, MAX_SUB_S, dMax > 0 ? (MAX_IMPLICIT_RATIO * cs * cs) / dMax : Infinity);
      balance(sub);
      if (!anyIce) {
        t += sub;
        steps++;
        continue;
      }
      // Solve (I − dt·∇·D∇) H' = H + dt·∇·(D∇z)  for H'.
      const h0 = this.h0Buf;
      for (let i = 0; i < n; i++) h0[i] = ice[i];
      void correction;
      const rhs = this.rhsBuf;
      const diag = this.diagBuf;
      for (let i = 0; i < n; i++) {
        const x = i % W;
        let r = h0[i];
        let dg = 1;
        const face = (D: number, j: number) => {
          if (D <= 0) return;
          r += sub * k2 * D * (z[j] - z[i]);
          dg += sub * k2 * D;
        };
        if (x < W - 1) face(Dx[i], i + 1);
        if (x > 0) face(Dx[i - 1], i - 1);
        if (i + W < n) face(Dy[i], i + W);
        if (i >= W) face(Dy[i - W], i - W);
        rhs[i] = r;
        diag[i] = dg;
      }
      const hNew = this.solve(rhs, diag, h0, sub * k2, W, n);
      if (!this.lastSolveConverged) this.unconverged++;
      // Move ice with the fluxes implied by the implicit solution, as pairwise donor-limited
      // transfers: exactly conservative however loosely CG converged, and never negative.
      const fq = this.fqBuf; // face volume (m of ice over a cell), + = towards +x / +y
      fq.fill(0);
      const out = this.outBuf;
      out.fill(0);
      const qc = this.qcBuf; // |q| at cell centres (m²/s), for sliding
      qc.fill(0);
      const faceQ = (i: number, j: number, D: number, k: number) => {
        if (D <= 0) return;
        const q = (-D * (z[j] + hNew[j] - z[i] - hNew[i])) / cs; // m²/s, + = i → j
        qc[i] += Math.abs(q) / 2;
        qc[j] += Math.abs(q) / 2;
        const v = (q * cs * sub) / A;
        fq[k] = v;
        out[v > 0 ? i : j] += Math.abs(v);
      };
      for (let i = 0; i < n; i++) {
        const x = i % W;
        if (x < W - 1) faceQ(i, i + 1, Dx[i], 2 * i);
        if (i + W < n) faceQ(i, i + W, Dy[i], 2 * i + 1);
      }
      const lim = this.limBuf;
      for (let i = 0; i < n; i++) lim[i] = out[i] > ice[i] ? ice[i] / out[i] : 1;
      const dIce = this.dIceBuf;
      dIce.fill(0);
      const dDeb = this.dDebBuf;
      dDeb.fill(0);
      const transfer = (from: number, to: number, v: number) => {
        const h = v * lim[from];
        if (h <= 0) return;
        const frac = ice[from] > 0 ? Math.min(1, h / ice[from]) : 0;
        dIce[from] -= h;
        dIce[to] += h;
        const dd = deb[from] * frac;
        dDeb[from] -= dd;
        dDeb[to] += dd;
      };
      for (let i = 0; i < n; i++) {
        const x = i % W;
        const vx = fq[2 * i];
        const vy = fq[2 * i + 1];
        if (x < W - 1 && vx !== 0) vx > 0 ? transfer(i, i + 1, vx) : transfer(i + 1, i, -vx);
        if (i + W < n && vy !== 0) vy > 0 ? transfer(i, i + W, vy) : transfer(i + W, i, -vy);
      }
      for (let i = 0; i < n; i++) {
        ice[i] = Math.max(0, ice[i] + dIce[i]);
        deb[i] = Math.max(0, deb[i] + dDeb[i]);
      }
      // Map edges: ice leaves where the ground slopes outward (explicit, donor-limited).
      const edgeOut = (i: number, inner: number) => {
        const h = ice[i];
        if (h <= 0) return;
        const gs = (z[i] - z[inner]) / cs;
        if (gs >= 0) return;
        const D = (1 + fs) * GAMMA * Math.pow(h, 5) * Math.min(MAX_SLOPE2, gs * gs);
        const out = Math.min(h, (D * -gs * sub) / cs);
        if (out <= 0) return;
        const dd = (deb[i] * out) / h;
        ice[i] -= out;
        deb[i] -= dd;
        exported += out;
        debExported += dd;
      };
      for (let x = 0; x < W; x++)
        if (H > 1) {
          edgeOut(x, x + W);
          edgeOut((H - 1) * W + x, (H - 2) * W + x);
        }
      for (let y = 0; y < H; y++)
        if (W > 1) {
          edgeOut(y * W, y * W + 1);
          edgeOut(y * W + W - 1, y * W + W - 2);
        }
      // Abrasion from the sliding speed u_b = f_s/(1+f_s) · |q| / H (optionally coupled across the glacier).
      const ubField = this.ubBuf;
      ubField.fill(0);
      for (let i = 0; i < n; i++) if (ice[i] > MIN_SLIDE_ICE_M) ubField[i] = Math.min(MAX_SLIDE_MS, (slideShare * qc[i]) / ice[i]);
      if (p.slidingCoupling && p.slidingCoupling > 0) this.couple(ubField, Math.round(p.slidingCoupling));
      for (let i = 0; i < n; i++) {
        const h = ice[i];
        if (h <= MIN_SLIDE_ICE_M) continue;
        const ub = ubField[i];
        const ubYr = ub * YEAR_S;
        if (ubYr > this.maxSlideMPerYr) this.maxSlideMPerYr = ubYr;
        let law = p.erosionLaw === 'herman' ? HERMAN_KG * ubYr * ubYr * (sub / YEAR_S) : p.abrasionK * ub * sub;
        // Rotational slip over-deepening in cirque/corrie hollows (steep backwall + concave bed near ELA)
        if (p.slidingCoupling && p.slidingCoupling > 0 && h < 110) {
          const x = i % W;
          const y = (i / W) | 0;
          if (x > 0 && x < W - 1 && y > 0 && y < H - 1) {
            const zi = z[i];
            const maxRise = Math.max(z[i - 1] - zi, z[i + 1] - zi, z[i - W] - zi, z[i + W] - zi);
            const lap = (z[i - 1] + z[i + 1] + z[i - W] + z[i + W]) * 0.25 - zi;
            if (maxRise > 0.32 * cs && lap > 0) {
              law *= 1 + Math.min(0.28, lap / (cs * 0.4));
            }
          }
        }
        // M20-C03: Lateral valley-wall plucking & spur truncation — widens V-shaped river valleys into U-shaped glacial troughs
        if (p.slidingCoupling && p.slidingCoupling > 0) {
          const x = i % W;
          const y = (i / W) | 0;
          if (x > 0 && x < W - 1 && y > 0 && y < H - 1) {
            const zi = z[i];
            let maxTroughDrop = 0;
            for (const nb of [i - 1, i + 1, i - W, i + W]) {
              if (ice[nb] > 45 && zi > z[nb] + 3) {
                maxTroughDrop = Math.max(maxTroughDrop, zi - z[nb]);
              }
            }
            if (maxTroughDrop > 0) {
              law *= 1 + Math.min(0.42, maxTroughDrop / (cs * 1.1));
            }
          }
        }
        // Optional cap at the measured range for temperate valley glaciers (~1–10 mm/yr, Hallet et al. 1996).
        const cap = p.maxErosionMmYr ? (p.maxErosionMmYr / 1000) * (sub / YEAR_S) : Infinity;
        const e = Math.min(law, cap) * this.erosionFactor;
        if (e > 0) {
          const [tot, bed] = this.erode(i, e);
          if (this.erosionRecord) this.erosionRecord[i] += tot;
          eroded += tot;
          erodedB += bed;
          deb[i] += tot;
        }
      }
      t += sub;
      steps++;
    }
    // 3. Debris drops where the ice has (nearly) gone: moraine.
    for (let i = 0; i < n; i++)
      if (deb[i] > 0 && ice[i] < DROP_ICE_M) {
        this.drop(i, deb[i]);
        dropped += deb[i];
        deb[i] = 0;
      }
    const L = this.ledger;
    L.accumulated += acc * A;
    L.ablated += abl * A;
    L.calved += calv * A;
    L.exported += exported * A;
    L.correction += correction * A;
    L.debrisExported += debExported * A;
    L.eroded += eroded * A;
    L.erodedBedrock += erodedB * A;
    L.deposited += dropped * A;
    L.timeS += t;
    L.lagS += dtGeo - t;
    return melt;
  }

  /** Average a field over ice-covered cells (thicker than MIN_SLIDE_ICE_M) within r cells: two passes of a separable box filter. */
  private couple(f: Float64Array, r: number) {
    const w = this.world;
    const W = w.width;
    const H = w.height;
    const ice = w.iceThicknessM;
    const on = (i: number) => ice[i] > MIN_SLIDE_ICE_M;
    const tmp = this.coupleTmpBuf;
    for (let pass = 0; pass < 2; pass++) {
      for (let y = 0; y < H; y++)
        for (let x = 0; x < W; x++) {
          const i = y * W + x;
          if (!on(i)) continue;
          let s = 0;
          let c = 0;
          for (let k = Math.max(0, x - r); k <= Math.min(W - 1, x + r); k++) if (on(y * W + k)) (s += f[y * W + k]), c++;
          tmp[i] = s / c;
        }
      for (let y = 0; y < H; y++)
        for (let x = 0; x < W; x++) {
          const i = y * W + x;
          if (!on(i)) continue;
          let s = 0;
          let c = 0;
          for (let k = Math.max(0, y - r); k <= Math.min(H - 1, y + r); k++) if (on(k * W + x)) (s += tmp[k * W + x]), c++;
          f[i] = s / c;
        }
    }
  }

  /** Mass-balance change from slope aspect (m/yr): +k on steep NE-facing ground, −k on SW-facing (ground surface). */
  private aspectTerm(k: number): Float32Array {
    const w = this.world;
    const W = w.width;
    const H = w.height;
    const cs = w.cellSizeM;
    const z = this.surface;
    const out = new Float32Array(W * H);
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        const xl = x > 0 ? x - 1 : x;
        const xr = x < W - 1 ? x + 1 : x;
        const yd = y > 0 ? y - 1 : y;
        const yu = y < H - 1 ? y + 1 : y;
        const gx = (z[y * W + xr] - z[y * W + xl]) / ((xr - xl) * cs);
        const gy = (z[yu * W + x] - z[yd * W + x]) / ((yu - yd) * cs);
        const s = Math.hypot(gx, gy);
        if (s < 1e-3) continue;
        // Downslope direction (−∇z) as a unit vector; NE = (1, 1)/√2 (x east, y north).
        const facing = (-gx - gy) / (s * Math.SQRT2);
        out[y * W + x] = k * facing * Math.min(1, s / 0.3);
      }
    return out;
  }

  /** SIA face diffusivity (m²/s) between i and j using the upstream cell's ice thickness. */
  private faceD(i: number, j: number, x: number, y: number, alongX: boolean, fs: number): number {
    const ice = this.world.iceThicknessM;
    const z = this.surface;
    const si = z[i] + ice[i];
    const sj = z[j] + ice[j];
    const hUp = si >= sj ? ice[i] : ice[j];
    if (hUp <= 0) return 0;
    const cs = this.world.cellSizeM;
    const gn = (sj - si) / cs;
    const gt = this.transverse(x, y, alongX ? x + 1 : x, alongX ? y : y + 1, alongX);
    return (1 + fs) * GAMMA * Math.pow(hUp, 5) * Math.min(MAX_SLOPE2, gn * gn + gt * gt);
  }

  /** Jacobi-preconditioned CG for the 5-point system diag·x − c·Σ D_f·x_nb = rhs (SPD). */
  private solve(rhs: Float64Array, diag: Float64Array, x0: Float64Array, c: number, W: number, n: number): Float64Array {
    const Dx = this.qx;
    const Dy = this.qy;
    const mul = (v: Float64Array, out: Float64Array) => {
      for (let i = 0; i < n; i++) {
        const x = i % W;
        let r = diag[i] * v[i];
        if (x < W - 1 && Dx[i] > 0) r -= c * Dx[i] * v[i + 1];
        if (x > 0 && Dx[i - 1] > 0) r -= c * Dx[i - 1] * v[i - 1];
        if (i + W < n && Dy[i] > 0) r -= c * Dy[i] * v[i + W];
        if (i >= W && Dy[i - W] > 0) r -= c * Dy[i - W] * v[i - W];
        out[i] = r;
      }
    };
    const x = this.cgXBuf;
    for (let i = 0; i < n; i++) x[i] = x0[i];
    const r = this.cgRBuf;
    const zv = this.cgZvBuf;
    const pv = this.cgPvBuf;
    const ap = this.cgApBuf;
    mul(x, ap);
    let bn = 0;
    for (let i = 0; i < n; i++) {
      r[i] = rhs[i] - ap[i];
      zv[i] = r[i] / diag[i];
      pv[i] = zv[i];
      bn += rhs[i] * rhs[i];
    }
    let rz = 0;
    for (let i = 0; i < n; i++) rz += r[i] * zv[i];
    const tol = 1e-12 * Math.max(bn, 1e-30); // relative residual 1e-6
    this.lastSolveConverged = false;
    for (let it = 0; it < 400; it++) {
      let rr = 0;
      for (let i = 0; i < n; i++) rr += r[i] * r[i];
      if (rr <= tol) {
        this.lastSolveConverged = true;
        break;
      }
      mul(pv, ap);
      let pap = 0;
      for (let i = 0; i < n; i++) pap += pv[i] * ap[i];
      if (pap <= 0) break;
      const alpha = rz / pap;
      for (let i = 0; i < n; i++) {
        x[i] += alpha * pv[i];
        r[i] -= alpha * ap[i];
        zv[i] = r[i] / diag[i];
      }
      let rzNew = 0;
      for (let i = 0; i < n; i++) rzNew += r[i] * zv[i];
      const beta = rzNew / rz;
      rz = rzNew;
      for (let i = 0; i < n; i++) pv[i] = zv[i] + beta * pv[i];
    }
    return x;
  }

  /** Mean of the transverse surface slope at the two cells of a face. */
  private transverse(x0: number, y0: number, x1: number, y1: number, alongX: boolean): number {
    const w = this.world;
    const W = w.width;
    const H = w.height;
    const cs = w.cellSizeM;
    const s = (x: number, y: number) => {
      const i = Math.max(0, Math.min(H - 1, y)) * W + Math.max(0, Math.min(W - 1, x));
      return this.surface[i] + w.iceThicknessM[i];
    };
    if (alongX) return (s(x0, y0 + 1) - s(x0, y0 - 1) + s(x1, y1 + 1) - s(x1, y1 - 1)) / (4 * cs);
    return (s(x0 + 1, y0) - s(x0 - 1, y0) + s(x1 + 1, y1) - s(x1 - 1, y1)) / (4 * cs);
  }

  /** Lower the ground at i by e (loose first, then bedrock). Returns [total, bedrock] actually removed. */
  private erode(i: number, e: number): [number, number] {
    const w = this.world;
    const loose = w.looseSedimentThicknessM;
    const fromLoose = Math.min(loose[i], e);
    const nl = Math.fround(loose[i] - fromLoose);
    const dl = loose[i] - nl;
    loose[i] = nl;
    let db = 0;
    if (e - fromLoose > 0) {
      const b = w.bedrockElevationM;
      const nb = Math.fround(b[i] - (e - fromLoose));
      db = b[i] - nb;
      b[i] = nb;
      refreshExposed(w, i);
    }
    this.surface[i] = w.bedrockElevationM[i] + loose[i];
    return [dl + db, db];
  }

  /** Lay debris down as loose sediment (exact float32 delta booked by the caller's amount). */
  private drop(i: number, v: number) {
    const w = this.world;
    const loose = w.looseSedimentThicknessM;
    if (this.outwash && this.meltwaterShare > 0) {
      const o = v * this.meltwaterShare;
      this.outwash[i] += o;
      v -= o;
    }
    loose[i] = loose[i] + v;
    if (this.moraine) this.moraine[i] += v;
    this.surface[i] = w.bedrockElevationM[i] + loose[i];
  }
}

/** Ice closure: initial + accumulated − ablated − calved vs current, relative. */
export function iceClosure(l: GlacierLedger, current: number): number {
  const expected = l.initialIce + l.accumulated + l.correction - l.ablated - l.calved - l.exported;
  return Math.abs(current - expected) / Math.max(1e-9, l.initialIce + l.accumulated);
}

/** Debris closure: initial + eroded − deposited vs current debris in ice, relative. */
export function debrisClosure(l: GlacierLedger, current: number): number {
  const expected = l.initialDebris + l.eroded - l.deposited - l.debrisExported;
  return Math.abs(current - expected) / Math.max(1e-9, l.initialDebris + l.eroded);
}
