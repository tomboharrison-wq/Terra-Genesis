import {
  BufferAttribute,
  BufferGeometry,
  Color,
  DataTexture,
  DoubleSide,
  FloatType,
  Mesh,
  NearestFilter,
  RGBAFormat,
  ShaderMaterial,
  Texture,
  type WebGLRenderer,
} from 'three';
import type { Engine } from '../engine/engine';

export type WaterView = 'water' | 'depth' | 'speed' | 'off';

/**
 * Renders simulated surface water. Geometry is a grid with one vertex per cell; the vertex
 * shader reads ground (z, sea flag) and water state (depth, vx, vy) textures, so the surface
 * height, colour, foam and flow streaks all come from the solver's fields:
 *   - GPU backend: the solver's own state texture is bound directly (no readback);
 *   - CPU backend: a DataTexture mirrored from world.waterDepthM / sim.vx / sim.vy.
 * Sea cells are not drawn here (the sea-level surface covers them).
 */
export class WaterLayer {
  readonly mesh: Mesh<BufferGeometry, ShaderMaterial>;
  private ground: DataTexture;
  private groundData: Float32Array;
  private cpuState: DataTexture;
  private cpuData: Float32Array;
  private gpuState = new Texture();
  private gpuBed = new Texture();
  private lastRevision = -1;

  constructor(private engine: Engine, private renderer: WebGLRenderer, index: BufferAttribute, positions: Float32Array) {
    const w = engine.world;
    const n = w.width * w.height;
    this.groundData = new Float32Array(n * 4);
    this.ground = this.dataTex(this.groundData);
    this.cpuData = new Float32Array(n * 4);
    this.cpuState = this.dataTex(this.cpuData);
    const geo = new BufferGeometry();
    geo.setIndex(index);
    geo.setAttribute('position', new BufferAttribute(positions, 3));
    const mat = new ShaderMaterial({
      transparent: true,
      depthWrite: false,
      side: DoubleSide,
      uniforms: {
        uGround: { value: this.ground },
        uState: { value: this.cpuState },
        uCs: { value: w.cellSizeM },
        uSea: { value: w.seaLevelM },
        uSize: { value: [w.width, w.height] },
        uTime: { value: 0 },
        uMode: { value: 0 },
        uSunDir: { value: [0.5, 0.7, 0.3] },
        uShallow: { value: new Color(0x4eb8ae) },
        uDeep: { value: new Color(0x0b3d69) },
        uFogColor: { value: new Color(0xd2e2ee) },
        uFogNear: { value: 1e4 },
        uFogFar: { value: 1e5 },
        uLift: { value: 0.3 },
      },
      vertexShader: VERT,
      fragmentShader: FRAG,
    });
    this.mesh = new Mesh(geo, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 3;
    this.updateGround();
  }

  private dataTex(data: Float32Array): DataTexture {
    const w = this.engine.world;
    const t = new DataTexture(data, w.width, w.height, RGBAFormat, FloatType);
    t.minFilter = t.magFilter = NearestFilter;
    t.generateMipmaps = false;
    t.needsUpdate = true;
    return t;
  }

  setView(v: WaterView) {
    const u = this.mesh.material.uniforms;
    this.mesh.visible = v !== 'off';
    u.uMode.value = v === 'depth' ? 1 : v === 'speed' ? 2 : 0;
  }

  setFog(near: number, far: number, sunDir: number[], lift: number) {
    const u = this.mesh.material.uniforms;
    u.uFogNear.value = near;
    u.uFogFar.value = far;
    u.uSunDir.value = sunDir;
    u.uLift.value = lift;
  }

  /** Refresh the CPU bed mirror texture: bedrock, loose, suspended (CPU backend / fallback). */
  updateGround() {
    const w = this.engine.world;
    const g = this.groundData;
    for (let i = 0; i < w.bedrockElevationM.length; i++) {
      g[i * 4] = w.bedrockElevationM[i];
      g[i * 4 + 1] = w.looseSedimentThicknessM[i];
      g[i * 4 + 2] = w.sedimentSuspendedM[i];
    }
    this.ground.needsUpdate = true;
  }

  /** Bind the current water state texture (call every frame before rendering). */
  update(timeS: number) {
    const u = this.mesh.material.uniforms;
    u.uTime.value = timeS;
    u.uSea.value = this.engine.world.seaLevelM;
    const gpu = this.engine.gpu;
    if (gpu) {
      // Bind the solver's raw ping-pong textures into three without re-uploading.
      (this.renderer.properties.get(this.gpuState) as { __webglTexture?: WebGLTexture }).__webglTexture = gpu.stateTexture;
      (this.renderer.properties.get(this.gpuBed) as { __webglTexture?: WebGLTexture }).__webglTexture = gpu.bedTexture;
      u.uState.value = this.gpuState;
      u.uGround.value = this.gpuBed;
      return;
    }
    u.uState.value = this.cpuState;
    u.uGround.value = this.ground;
    if (this.engine.waterRevision === this.lastRevision) return;
    this.lastRevision = this.engine.waterRevision;
    if (this.engine.erosionActive) this.updateGround();
    const d = this.engine.world.waterDepthM;
    const vx = this.engine.water.vx;
    const vy = this.engine.water.vy;
    const s = this.cpuData;
    for (let i = 0; i < d.length; i++) {
      s[i * 4] = d[i];
      s[i * 4 + 1] = vx[i];
      s[i * 4 + 2] = vy[i];
    }
    this.cpuState.needsUpdate = true;
  }

  dispose() {
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
    this.ground.dispose();
    this.cpuState.dispose();
  }
}

const VERT = /* glsl */ `
uniform sampler2D uGround;
uniform sampler2D uState;
uniform float uCs;
uniform float uSea;
uniform ivec2 uSize;
uniform int uMode;
uniform float uLift;
varying float vDepth;
varying float vConc;
varying vec2 vVel;
varying vec3 vNormal2;
varying vec3 vWorld;
varying float vHide;

float depthAt(ivec2 c) {
  c = clamp(c, ivec2(0), uSize - 1);
  return texelFetch(uState, c, 0).r;
}

float headAt(ivec2 c, float fallback) {
  c = clamp(c, ivec2(0), uSize - 1);
  vec4 g = texelFetch(uGround, c, 0);
  float z = g.r + g.g;
  float d = texelFetch(uState, c, 0).r;
  return d > 0.004 && z >= uSea ? z + d : fallback;
}

void main() {
  ivec2 c = ivec2(int(round(position.x / uCs)), int(round(-position.z / uCs)));
  vec4 g = texelFetch(uGround, c, 0);
  vec4 s = texelFetch(uState, c, 0);
  float d = max(s.r, 0.0);
  float z = g.r + g.g;
  bool isSea = z < uSea && d <= 0.004;
  bool wet = d > 0.004 && !isSea;
  // Check 8-neighbourhood so dry bank vertices bordering a wet channel stay above the ground surface
  // instead of diving underground and clipping diagonal river triangles into beaded diamonds.
  float maxNbD = max(
    max(max(depthAt(c + ivec2(1, 0)), depthAt(c - ivec2(1, 0))), max(depthAt(c + ivec2(0, 1)), depthAt(c - ivec2(0, 1)))),
    max(max(depthAt(c + ivec2(1, 1)), depthAt(c + ivec2(-1, 1))), max(depthAt(c + ivec2(1, -1)), depthAt(c + ivec2(-1, -1))))
  );
  bool nearWet = wet || (maxNbD > 0.004 && !isSea);
  float lift = max(0.05, uLift * 0.35);
  float h;
  if (uMode == 0) h = nearWet ? z + d + lift : z - max(0.3, uLift);
  else h = z + d + uLift;
  vDepth = isSea ? -1.0 : d;
  vHide = (isSea || (!nearWet && uMode == 0)) ? 1.0 : 0.0;
  vConc = d > 0.008 ? g.b / d : 0.0;
  vVel = s.gb;
  float H = wet ? z + d : z;
  float hx = headAt(c + ivec2(1, 0), H) - headAt(c - ivec2(1, 0), H);
  float hy = headAt(c + ivec2(0, 1), H) - headAt(c - ivec2(0, 1), H);
  // world (x east, y north, z up) → three (x, z, -y)
  vNormal2 = normalize(vec3(-hx / (2.0 * uCs), 1.0, hy / (2.0 * uCs)));
  vec4 wp = modelMatrix * vec4(position.x, h, position.z, 1.0);
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;

const FRAG = /* glsl */ `
uniform float uTime;
uniform int uMode;
uniform vec3 uSunDir, uShallow, uDeep, uFogColor;
uniform float uFogNear, uFogFar;
varying float vDepth;
varying float vConc;
varying vec2 vVel;
varying vec3 vNormal2;
varying vec3 vWorld;
varying float vHide;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) {
  vec2 i = floor(p), f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
vec3 ramp(float t, vec3 a, vec3 b, vec3 c) { return t < 0.5 ? mix(a, b, t * 2.0) : mix(b, c, t * 2.0 - 1.0); }

float flowField(vec2 p, vec2 flow, float speed, float t) {
  float ph0 = fract(t * 0.25);
  float ph1 = fract(t * 0.25 + 0.5);
  vec2 dir = speed > 1e-4 ? flow / speed : vec2(1.0, 0.0);
  mat2 rot = mat2(dir.x, -dir.y, dir.y, dir.x);
  vec2 q0 = rot * (p - flow * ph0 * 1.2) * vec2(0.35, 2.4);
  vec2 q1 = rot * (p - flow * ph1 * 1.2) * vec2(0.35, 2.4);
  float w0 = abs(ph0 - 0.5) * 2.0;
  float adv = mix(vnoise(q0), vnoise(q1), w0);
  // Isotropic capillary ripples so standing lakes and slow pools also shimmer
  float cap = vnoise(p * 1.8 + vec2(t * 0.14, -t * 0.11)) * 0.55
            + vnoise(p * 4.1 - vec2(t * 0.19, t * 0.16)) * 0.45;
  float moving = smoothstep(0.03, 0.55, speed);
  return mix(cap, adv * 0.7 + cap * 0.3, moving);
}

void main() {
  if (vHide > 0.5) discard;
  float d = vDepth;
  float speed = length(vVel);
  if (uMode == 1) {
    if (d < 0.005) discard;
    float t = clamp(log(d / 0.01) / log(1e3), 0.0, 1.0);
    gl_FragColor = vec4(ramp(t, vec3(0.80, 0.93, 1.0), vec3(0.20, 0.55, 0.95), vec3(0.04, 0.12, 0.45)), 0.85);
    #include <colorspace_fragment>
    return;
  }
  if (uMode == 2) {
    if (d < 0.005) discard;
    float t = clamp(speed / 3.0, 0.0, 1.0);
    gl_FragColor = vec4(ramp(t, vec3(1.0, 0.95, 0.55), vec3(1.0, 0.57, 0.16), vec3(0.78, 0.10, 0.10)), 0.85);
    #include <colorspace_fragment>
    return;
  }
  if (d < 0.005) discard;

  vec3 n = normalize(vNormal2);
  vec2 flow = vec2(vVel.x, -vVel.y);
  vec2 p = vWorld.xz * 0.08;
  float eps = 0.25;
  float h0 = flowField(p, flow, speed, uTime);
  float hx = flowField(p + vec2(eps, 0.0), flow, speed, uTime) - h0;
  float hz = flowField(p + vec2(0.0, eps), flow, speed, uTime) - h0;
  float rippleAmp = mix(0.16, 0.34, smoothstep(0.05, 1.2, speed));
  n = normalize(n + vec3(-hx / eps, 0.0, -hz / eps) * rippleAmp);

  // Beer-Lambert exponential depth absorption
  vec3 transmittance = exp(-vec3(0.55, 0.18, 0.07) * clamp(d, 0.0, 12.0));
  vec3 col = mix(uDeep, uShallow, transmittance);

  // Turbidity from simulated suspended-sediment concentration (volume fraction s/d)
  float turb = smoothstep(0.0002, 0.009, vConc);
  col = mix(col, vec3(0.56, 0.44, 0.29), turb * 0.86);

  // Subtle caustics in clear shallow water
  if (d < 2.5 && turb < 0.5) {
    float c = smoothstep(0.58, 0.85, h0);
    col += vec3(0.12, 0.18, 0.16) * c * (1.0 - turb * 2.0) * (1.0 - d / 2.5);
  }

  vec3 v = normalize(cameraPosition - vWorld);
  vec3 l = normalize(uSunDir);
  vec3 hVec = normalize(l + v);
  float diff = 0.56 + 0.44 * max(dot(n, l), 0.0);
  float spec = pow(max(dot(n, hVec), 0.0), 140.0) * 0.85;
  float fres = 0.02 + 0.98 * pow(1.0 - max(dot(n, v), 0.0), 4.5);
  vec3 skyRefl = mix(vec3(0.48, 0.68, 0.86), vec3(0.82, 0.90, 0.96), pow(1.0 - max(n.y, 0.0), 2.0));
  col = mix(col * diff, skyRefl, fres * 0.38) + vec3(1.0, 0.97, 0.90) * spec;

  // Foam/whitewater where flow is supercritical/fast (Froude proxy) or breaking along shallow banks
  float froude = speed / sqrt(9.81 * max(d, 0.01));
  float foam = smoothstep(0.75, 1.7, froude) * smoothstep(0.42, 0.82, h0) * smoothstep(0.35, 1.3, speed) * smoothstep(0.01, 0.15, d);
  col = mix(col, vec3(0.94, 0.97, 0.98), foam * 0.82);

  // Feathered shoreline alpha so diagonal channels never look jagged
  float edgeFeather = smoothstep(0.005, 0.032, d);
  float depthOpacity = mix(0.28, 0.93, smoothstep(0.01, 1.2, d));
  float alpha = edgeFeather * max(depthOpacity, foam * 0.9);

  float fogF = smoothstep(uFogNear, uFogFar, length(cameraPosition - vWorld));
  col = mix(col, uFogColor, fogF);
  gl_FragColor = vec4(col, alpha);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;
