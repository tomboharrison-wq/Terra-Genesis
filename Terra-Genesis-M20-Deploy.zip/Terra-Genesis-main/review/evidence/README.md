# Evidence captured for this ZIP

These checks were run against the source exported for this package on 18 November 2026. They are distinct from older results recorded in the repository documentation.

- `source-integrity.log`: all 266 tracked source files match GitHub commit `8ce4fa53bda744a641d6d8dc054046b568a7fc2b` byte for byte.
- `build.log`: strict TypeScript checking and a fresh Vite production build succeeded. Build identity is `8ce4fa5`.
- `unit-tests.log`: 327 tests in 61 files passed using `npm test -- --maxWorkers=2`.
- `gpu-check.log`: all 12 CPU/GPU comparisons passed in installed Chrome using SwiftShader software graphics.
- `live-landforms-check.log`: 15 checks passed against the included build served by `review/serve.py`, including actual coastal topology, worker changes, waterfall erosion/collapse, zero forcing, levee deposition, ordinary-world restoration and no browser errors.
- `../screenshots/`: ten screenshots captured by that same focused browser check, covering five coastal stages, four waterfall stages and the levee transect.

Validation used Node.js v26.13.1 and npm 11.20.0 on macOS, with the workspace's already installed dependencies linked temporarily during validation. That temporary dependency link is excluded from the ZIP. For an independent check, install with `npm ci` and use the committed lockfile.

The full older e2e suite, a fresh dependency installation, real-device graphics performance and the compiled Electron app were not tested for this ZIP. The raw logs and known limitations are supplied to support independent assessment.
