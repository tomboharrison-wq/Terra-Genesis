"""Serve the included production build using only the Python 3 standard library."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
import threading
import webbrowser

root = Path(__file__).resolve().parents[1] / "dist"
port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
if not (root / "index.html").is_file():
    raise SystemExit("The dist folder is missing. Restore it from the ZIP or run npm run build.")

try:
    server = ThreadingHTTPServer(("127.0.0.1", port), partial(SimpleHTTPRequestHandler, directory=str(root)))
except OSError as error:
    raise SystemExit(f"Cannot start the review server: {error}. Try another port.") from error

url = f"http://127.0.0.1:{port}/"
print(f"Terra Genesis reviewer build: {url}\nKeep this window open. Press Ctrl+C to stop.", flush=True)
threading.Timer(0.5, webbrowser.open, args=(url,)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
