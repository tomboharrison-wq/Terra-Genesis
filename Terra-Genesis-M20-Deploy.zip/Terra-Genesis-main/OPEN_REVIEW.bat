@echo off
cd /d "%~dp0"
py -3 review\serve.py
pause
