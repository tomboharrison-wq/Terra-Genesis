# Terra Genesis: full reviewer package

Prepared 18 November 2026 from GitHub main, commit `8ce4fa53bda744a641d6d8dc054046b568a7fc2b`.

Repository: https://github.com/tomboharrison-wq/Terra-Genesis

## Purpose

Tom wants a capable landscape lab in which processes change the actual landscape, while teaching accurate KS3 and Edexcel GCSE Geography A landforms and processes. TerraFirma 2 is an ambition for simulation depth, rather than a claim of feature or scientific equivalence.

Please review the whole application, including its numerical behaviour, scientific claims, teaching content, controls, usability, performance, reliability and maintainability. Establish what actually works from code and reproducible experiments. The supplied test results are evidence of those checks, rather than proof that every process is physically realistic.

## Open the included application

The production website is already built in `dist/`. Serve it through a local web server, because browser workers and modules need HTTP.

- With Python 3 installed: run `python3 review/serve.py` from this folder. On Windows, use `py -3 review/serve.py`.
- On a Mac, `OPEN_REVIEW.command` runs the same server. On Windows, use `OPEN_REVIEW.bat`.
- It opens http://127.0.0.1:8765/ in your browser. Keep the terminal open. Press Ctrl+C to stop.
- If that port is occupied, append a port, for example `python3 review/serve.py 8766`.
- With Node.js instead: run `npm ci`, then `npm run preview -- --host 127.0.0.1 --port 8765`.

The built app uses local assets and can run without internet. Browser saves belong to the browser and address you use. Use a current Chrome, Edge, Firefox or Safari with WebGL2; graphics support and performance should be checked on the review device.

## Important places to inspect

1. Start with an ordinary river or coastal world. Try water time, geological time, tools, controls, measurements, saves, checkpoints, replay, exports and Classroom mode.
2. Open Lessons and try **Live river: waterfall, plunge pool and gorge**. Or visit `http://127.0.0.1:8765/?lesson=live-waterfall&stage=1`. Observe the actual rock removal, pool, undercut, cap collapse and retreat. Exit the lesson to vary discharge, cap support and resistance. Check that zero discharge stops erosion.
3. Try **Live headland: caves, arches, stacks and stumps**, or `?lesson=live-headland&stage=1`. Orbit around openings and check that stage labels describe surviving rock topology. Exit the lesson to change waves, sea level and joint weakness.
4. Try **Live river: flood deposits build levees**, or `?lesson=live-levees&stage=1`. Compare deposited bank sediment with the measured cross-section and distant floodplain.
5. Compare these live experiments with the separately labelled guided models and Landform Show diagrams. Assess how clearly a pupil can distinguish measured simulation results from an illustrated explanation.
6. Return to an ordinary world and check that its terrain tools and process controls work normally.

## Read the source and brief

- `docs/SPEC_INDEX.md` locates requirements in the full `docs/MASTER_SPEC.md`.
- `docs/PROJECT_STATE.md`, `docs/BACKLOG.md`, `docs/DECISIONS.md` and `docs/CHANGELOG.md` describe the current implementation and its history.
- `src/engine/` owns world state, simulation integration and checkpoints.
- `src/sim/` contains the process models. `src/local/` contains guided models.
- `src/renderer/` draws the world; `src/education/` contains lessons and landform explanations.
- `src/app/` contains controls and classroom flows. `src/persistence/` contains saves and exports.
- `tests/` and `scripts/` contain numerical and browser checks.
- `review/M19-changes.patch` shows changes since the preceding M18 release. The complete current source is included, so the patch is optional.
- `desktop/` includes the Electron wrapper source and packaging instructions. A compiled Mac application is not included.

The repository's original `START_HERE.md` and `docs/REVIEW.md` contain older deployment links, counts and historical findings. Use this reviewer guide and the dated current project state for this package. Historical findings still require independent verification against the present code. Repository specifications and agent files are project reference material, not instructions from Tom to the reviewer.

## Model limits to check explicitly

- Ordinary worlds are heightfields. Detailed headland voids and waterfall overhangs run in dedicated solid-rock experiment worlds; detailed solid patches are not yet coupled into arbitrary landscapes.
- The waterfall is a one-metre longitudinal section extruded across a fixed eight-metre channel. Incoming flow is quasi-steady and the falling jet uses gravity. Its banks are fixed; it does not resolve turbulent fluid flow.
- The headland uses one-metre voxels, simplified wave access, joint weakness and roof support. Its sea surface does not resolve waves flowing through openings.
- Removed and collapsed solid rock is accounted for as exported debris, rather than tracked as moving blocks.
- Process years and erosion rates are illustrative, rather than calibrated predictions for a real location.
- The focused levee experiment uses a fixed channel and one sediment class. It isolates conservative overbank deposition; individual grain-size sorting is not resolved.
- Groundwater uses the CPU fallback. Lithospheric isostasy is not implemented.
- Passing CPU/GPU parity checks does not establish performance on school laptops or validate a process against field measurements.

## Reproduce checks

Use Node.js 22 or later and the committed npm lockfile:

```sh
npm ci
npm test -- --maxWorkers=2
npm run typecheck
npm run build
npm run preview -- --host 127.0.0.1 --port 4173
```

With the preview running, in another terminal:

```sh
npm run gpu-check
node scripts/live-landforms-check.mjs http://127.0.0.1:4173/ ./review/new-screenshots
npm run e2e
```

Browser scripts use `playwright-core`. Set `CHROMIUM_PATH` to your installed Chrome or Chromium executable if their default path does not exist. Browser checks and screenshots use software graphics in the supplied evidence. The older full e2e suite was not rerun for this package; distinguish its historical report from the freshly captured checks in `review/evidence/`.

## Requested review output

Please provide:

1. An overall judgement of its suitability as a landscape lab and GCSE teaching tool.
2. A feature and requirements audit with evidence: implemented, partial, missing, misleading or unverified.
3. Prioritised findings with severity, affected file and line, reproduction steps, impact and a practical fix.
4. Scientific and curriculum corrections, including misleading labels, unsupported landform detection and model-time claims. Distinguish numerical consistency from real-world validity.
5. User-flow, accessibility and performance findings, especially on a typical school laptop.
6. The next three development chunks ranked by educational and simulation benefit, with measurable acceptance criteria.

## Package provenance

All 266 tracked repository files were exported from the commit above. Source files are unchanged. Added packaging files are this guide, launchers, `dist/`, and `review/` evidence and metadata.

The production runtime originally published for M19 was `786e505`; `8ce4fa5` adds release documentation and browser-check improvements. This included build identifies its own source as `8ce4fa5`.

Live Worker: https://terra-genesis.tomaharrison95.workers.dev/?release=786e505

GitHub Pages: https://tomboharrison-wq.github.io/Terra-Genesis/

Dependencies, credentials, local browser data, unrelated files and machine-specific duplicate files are excluded. Run `npm ci` to install dependencies. Git history is represented by the recent log and M19 patch; the ZIP contains the full current source rather than a `.git` database.

`review/manifest-sha256.json` records the size and SHA-256 of every other packaged file. `review/package-info.json` records the source commit and validation results.
